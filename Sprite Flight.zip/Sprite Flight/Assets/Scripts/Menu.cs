using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class Menu : MonoBehaviour
{
    [SerializeField, Tooltip("The UI Document of player.")]
    UIDocument uiDocument;
    Button startButton;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        startButton = uiDocument.rootVisualElement.Q<Button>("StartButton");
        startButton.clicked += StartGame;
    }

    void StartGame()
    {
        SceneManager.LoadScene("Main");
    }
}
