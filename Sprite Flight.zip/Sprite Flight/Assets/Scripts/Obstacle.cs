using UnityEngine;
using UnityEngine.UIElements;

public class Obstacle : MonoBehaviour
{
    [Header("Size and Speed")]
    [SerializeField,Tooltip("The minimum size of the obstacle.")]
    private float minSize = 0.5f;
    [SerializeField, Tooltip("The maximum size of the obstacle.")]
    private float maxSize = 2.0f;

    [SerializeField, Tooltip("The minimum speed of the obstacle.")]
    private float minSpeed = 50f;
    [SerializeField, Tooltip("The maximum speed of the obstacle.")]
    private float maxSpeed = 150f;

    [SerializeField, Tooltip("Explosion Effect")]
    GameObject obstacleEffect;

    private Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        float ramdomSize = Random.Range(minSize, maxSize);
        transform.localScale = new Vector3(ramdomSize, ramdomSize, 1f);

        float randomSpeed = Random.Range(minSpeed, maxSpeed);
        Vector2 randomDirection = Random.insideUnitCircle;

        rb = GetComponent<Rigidbody2D>();
        rb.AddForce(randomDirection * randomSpeed);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Instantiate(obstacleEffect, transform.position, Quaternion.identity);
    }


}
