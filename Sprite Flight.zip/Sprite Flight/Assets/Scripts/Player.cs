using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class Player : MonoBehaviour
{
    
    [SerializeField, Tooltip("The force of player.")]
    private float force = 1f;

    [SerializeField, Tooltip("Max Speed of player.")]
    private float maxSpeed = 5f;

    [SerializeField, Tooltip("The Flame of ship.")]
    private GameObject flame;

    [SerializeField, Tooltip("The Multiplier Score of player.")]
    float multiplierScore = 10f;

    [SerializeField, Tooltip("The UI Document of player.")]
    UIDocument uiDocument;

    [SerializeField, Tooltip("The Explosion Effect of player.")]
    private GameObject explosionEffect;

    AudioSource audioSource;
    [SerializeField, Tooltip("The Sound of Thruster")]
    AudioClip soundThruster;
    [SerializeField, Tooltip("The Sound of Explosion")]
    AudioClip soundExplosion;


    Label scoreLabel;
    Button restartButton;
    Button startButton;

    float elipseTime = 0f;
    float score = 0f;
    private Rigidbody2D rb;

    

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        scoreLabel = uiDocument.rootVisualElement.Q<Label>("ScoreLabel");
        restartButton = uiDocument.rootVisualElement.Q<Button>("RestartButton");
        restartButton.clicked += RestartGame;
        restartButton.style.display = DisplayStyle.None;    

        startButton = uiDocument.rootVisualElement.Q<Button>("MenuButton");
        startButton.clicked += GoMenu;
        startButton.style.display = DisplayStyle.None;

        audioSource = GetComponent<AudioSource>();
        score = 0f;
        elipseTime = 0f;
    }

    void UpdateScore()
    {
        //score do player
        elipseTime += Time.deltaTime;
        score = elipseTime * multiplierScore;
        scoreLabel.text = "Score: " + Mathf.FloorToInt(score).ToString();
    }

    void MovePlayer()
    {
        if (Mouse.current.leftButton.isPressed)
        {
            //entrada de dados
            Vector3 worldPosition = Camera.main.ScreenToWorldPoint(Mouse.current.position.value);
            Vector2 direction = (worldPosition - transform.position).normalized;

            //efeito de som
            if (!audioSource.isPlaying)
            {
                audioSource.clip = soundThruster;
                audioSource.Play();
            }
                

            //movimento do player
            transform.up = direction;
            rb.AddForce(direction * force);

            //ativando a chama do player
            if (flame != null)
            {
                flame.SetActive(true);
            }
        }
        else
        {
            //desativando a chama do player
            if (flame != null)
            {
                flame.SetActive(false);
            }

            audioSource.Stop();
        }

        //limitando a velocidade do player
        if (rb.linearVelocity.magnitude > maxSpeed)
        {
            rb.linearVelocity = rb.linearVelocity.normalized * maxSpeed;
        }

    }
    // Update is called once per frame
    void Update()
    {
        MovePlayer();
        UpdateScore();
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Instantiate(explosionEffect, transform.position, Quaternion.identity);

        audioSource.Stop();
        AudioSource.PlayClipAtPoint(soundExplosion, transform.position);


        restartButton.style.display = DisplayStyle.Flex;
        startButton.style.display = DisplayStyle.Flex;

        Destroy(gameObject);
    }

    void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void GoMenu()
    {
        SceneManager.LoadScene("Menu");
    }

}
